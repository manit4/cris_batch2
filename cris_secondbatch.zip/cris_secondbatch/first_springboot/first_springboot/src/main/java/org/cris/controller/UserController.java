package org.cris.controller;

import java.util.List;

import org.cris.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cris.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
//	@Autowired
//	UserRepository userRepository;
	
//	@Autowired
//	User user;
	
	public UserController() {
		System.out.println("inside UserContro  constr....");
	}
	
	@RequestMapping("/msg")
	public String getMessage() {
		
		return "Hello everyone";
	}
	
	@RequestMapping("/getUser")
	public User getUser() {
		
//		System.out.println("The autowired user is "+this.user);
		
		User user = new User("vijay12", "1234", "Vijay", "Meena");
		
		return user;
	}
	
//	@RequestMapping("/getAllusers")
//	public List<User> getAllUsers() {
//		
//		User user1 = new User("vijay12", "1234", "Vijay", "Meena");
//		User user2 = new User("Munish12", "2345", "Munish", "Kumar");
//		
//		List<User> users = new ArrayList<User>();
//		users.add(user1);  users.add(user2);
//		
//		return users;
//	}
	
//	@RequestMapping("/getAllusers")
//	public List<User> getAllUsers() {
//		
//		//UserRepository userRepository = new UserRepository();
//		
//		return userRepository.getAllUsers();
//	}
	
	
//	@RequestMapping("/getUser/{id}")
//	public User getUserById(@PathVariable String id) {
//		
//		System.out.println("the id is "+id);
//		
//		return userRepository.getUserById(id);	
//	
//	}
	
	
	@GetMapping("/filteredData")
	public List<User> getFilteredData() {
		
		return userService.filteredUserByNameSize();
	}
}







