package com.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.to.User;

@RestController
public class UserController {
	
	@GetMapping("/msg")
	public String message() {
		
		return "Hello everyone";
	}
	@GetMapping("/getUser")
	public void getUser() {
		
		User user = new User(100, "Manit");
	}

}
