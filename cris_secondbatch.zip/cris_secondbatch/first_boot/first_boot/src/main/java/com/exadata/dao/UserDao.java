package com.exadata.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.exadata.db.DBUtils;
import com.exadata.to.User;
@Repository
public class UserDao {
	
	Connection conn = DBUtils.getConnection();
	
	
	public void saveUser(User user) throws SQLException{
		
			PreparedStatement statement =  conn.prepareStatement("insert into user values(?, ?, ?)");
//			statement.setInt(1, 10);
//			statement.setString(2, "Manit");
//			statement.setLong(3, 111111);
//			statement.executeUpdate();
			
			statement.setInt(1, user.getId());
			statement.setString(2, user.getName());
			statement.setString(3, user.getPassword());
			statement.executeUpdate();
	}
	
	

}
