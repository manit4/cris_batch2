package com.exadata;

import org.springframework.stereotype.Component;

@Component
public class Restaurant {
	
	public Restaurant() {
		System.out.println("inside Restaurant constr....");
	}

}
