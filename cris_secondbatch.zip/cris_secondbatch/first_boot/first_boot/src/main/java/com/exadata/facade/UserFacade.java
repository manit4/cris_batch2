package com.exadata.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.exadata.dao.UserDao;
import com.exadata.repository.UserRepository;
import com.exadata.to.User;

@Component
public class UserFacade {
	
	@Autowired
	UserRepository userRepository;
	
	@Transactional(propagation = Propagation.)
	public void saveUserFacade(User user) {
		
		userRepository.save(user);
		
		System.out.println("user Saved....");
	}

}
