package com.exadata.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogDataSourceAspect {

	@Around("target(javax.sql.DataSource)")
	public Object logDataSourceInfo(ProceedingJoinPoint joinPoint) throws Throwable {
		
		System.out.println("datasource tracker "+joinPoint.getSignature());
		
		System.out.println("method starting "+joinPoint.getSignature().getName());
		
		Object obj = joinPoint.proceed();
		
		System.out.println("method completed "+joinPoint.getSignature().getName());
	
		return obj;
	}
}
