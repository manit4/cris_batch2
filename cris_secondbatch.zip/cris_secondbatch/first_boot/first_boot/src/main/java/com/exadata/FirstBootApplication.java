package com.exadata;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.exadata.service.UserService;
import com.google.Coffee;

@SpringBootApplication
@ComponentScan("com.google, com.exadata")
@EnableTransactionManagement
public class FirstBootApplication implements CommandLineRunner{
	
	@Autowired
	UserService userService;

	public static void main(String[] args) {
		SpringApplication.run(FirstBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		userService.saveUser();
	}
	
//	@Bean
//	public Coffee getCoffe() {
//		
//		return new Coffee();
//	}

}
