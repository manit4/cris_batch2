package com.exadata.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exadata.facade.UserFacade;
import com.exadata.to.User;
@Service
public class UserService {
	
	@Autowired
	UserFacade userFacade;
	
	@Transactional
	public void saveUser() throws SQLException {
		
		for(int i = 0; i < 10; i++) {
			
			User user = new User(i, "Manit"+i, ""+i+i+i+i+i);
			
			userFacade.saveUserFacade(user);
			
//			if( i == 5) {
//				
//				throw new RuntimeException();
//			}
		}
	}

}
