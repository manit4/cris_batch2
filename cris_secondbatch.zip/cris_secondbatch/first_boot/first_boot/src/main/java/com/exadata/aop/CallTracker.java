package com.exadata.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class CallTracker {
	
	//@Pointcut(value= "execution(* com.exadata.service.UserService.*(..))")
	@Pointcut(value= "execution(* com.exadata.service.UserService.*(..)) || execution(* com.exadata.facade.UserFacade.*(..))")
	private void logMethodPointCut() {
		
	}
	
//	@Before(value="logMethodPointCut()")
//	public void logBeforeMethodCall() {
//		
//		System.out.println("method is starting....");
//	}
//	
//	@After(value="logMethodPointCut()")
//	public void logAfterMethodCall() {
//		
//		System.out.println("method is colpleted....");
//	}
	
	
	@Around(value="logMethodPointCut()")
	public void logAfterMethodCall(ProceedingJoinPoint joinPoint) throws Throwable {
		
		System.out.println("method is started...."+joinPoint.getSignature().getName());
		
		joinPoint.proceed();
		
		System.out.println("method is completed...."+joinPoint.getSignature().getName());
		
		//System.out.println("method started....");
		
		
	}

}
