package com.google;

import org.springframework.stereotype.Service;

@Service
public class Coffee {
	
	public Coffee() {
		System.out.println("inside Coffee constr....");
	}

}
