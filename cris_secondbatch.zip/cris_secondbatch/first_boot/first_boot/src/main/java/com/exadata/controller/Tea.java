package com.exadata.controller;

import org.springframework.stereotype.Controller;

@Controller
public class Tea {
	
	public Tea() {
		System.out.println("inside Tea constructor....");
	}

}
